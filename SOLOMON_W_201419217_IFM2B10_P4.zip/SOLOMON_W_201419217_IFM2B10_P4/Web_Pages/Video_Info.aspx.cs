﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Web_Pages_Video_Info : System.Web.UI.Page
{
    static string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connStr);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["User_ID"] == null)
        {
            Response.Redirect("Log_In.aspx");
        }

        con.Open();
        string query = "select * from [Video]";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.CommandType = CommandType.Text;
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                HtmlGenericControl p = new HtmlGenericControl("p");
                video_name.InnerText = (string)dr["Title"];
                video_info.InnerText = (string) dr["Description"];
            }
        }

        con.Close();
    }
}