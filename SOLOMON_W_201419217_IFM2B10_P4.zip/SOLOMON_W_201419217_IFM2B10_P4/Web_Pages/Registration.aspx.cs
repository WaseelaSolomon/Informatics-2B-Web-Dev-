﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{

    static string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connStr);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Unnamed1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into [User] values('"+type.Text+"', '"+fullname.Text+"', '"+email.Text+"', '"+name.Text+"', '"+password.Text+"')";
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("Log_In.aspx");
    }
}