﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Upload : System.Web.UI.Page
{
    static string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connStr);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["User_ID"] == null || Session["User_ID"].Equals("customer"))
        {
            Response.Redirect("Log_In.aspx");
        }
    }

    protected void upload_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into [Video] values('" + title.Text + "', '" + description.Text + "')";
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("Upload.aspx");
    }
}