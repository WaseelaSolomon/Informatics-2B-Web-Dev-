﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class VideoPage : System.Web.UI.Page
{
    static string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connStr);

    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["User_ID"] == null)
        {
            Response.Redirect("Log_In.aspx");
        }

        con.Open();
        string query = "select Title from [Video]";
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.CommandType = CommandType.Text;
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                HtmlGenericControl li = new HtmlGenericControl("li");
                video_list.Controls.Add(li);

                HtmlGenericControl anchor = new HtmlGenericControl("a");
                anchor.Attributes.Add("href", "Video_Info.aspx");
                anchor.InnerText = (string) dr["Title"];

                li.Controls.Add(anchor);
            }
        }

        con.Close();

    }
}