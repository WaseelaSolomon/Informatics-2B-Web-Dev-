﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Log_In : System.Web.UI.Page
{
    static string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connStr);

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void login_Click(object sender, EventArgs e)
    {
        if(name.Text.Length > 0 && password.Text.Length > 0)
        {
            con.Open();
            string query = "select * from [User] where UserName = '" +name.Text+"' AND Password = '"+password.Text+"' ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    if (dr["Type"].Equals("E"))
                    {
                        Session["User_ID"] = "employee";
                    }
                    else if (dr["Type"].Equals("C"))
                    {
                        Session["User_ID"] = "customer";
                    }
                    Response.Redirect("Default.aspx");
                }
            }

            con.Close();
        }
    }
}