//function to limit the # of checkboxes checked
function validateCheckboxes()
{
	//checkbox variables 
	var sport = document.getElementById("sport");
	var movie = document.getElementById("movie");
	var series = document.getElementById("series");
	
	//checking which checkboxes are checked
	if((sport.checked) && (movie.checked))
	{
		series.disabled = true;	//limit the number of checkboxes selected by disabling the third checkbox
	}
	else if((movie.checked) && (series.checked))
	{
		sport.disabled = true;	//limit the number of checkboxes selected by disabling the third checkbox
	}
	else if((sport.checked) && (series.checked))
	{
		movie.disabled = true;	//limit the number of checkboxes selected by disabling the third checkbox
	}
	else
	{
		//enable checkbox selection if one box is unchecked
		series.disabled = false;
		sport.disabled = false;
		movie.disabled = false;
	}
}

//function to check if a checkbox is checked
function isChecked(box)
{
	if(box.checked)
	{
		return true;
	}else
		return false;
}

//function to calculate the total cost
function cost(duration, checked)
{
	var total = 99 * duration;
	var discounted = 0;
	
	//check for upfront payment
	if(checked == true)
	{
		document.write("UPFRONT PAYMENT PAID" + "<br>");
		
		//conditions for discount
		if(duration < 6)
		{
			document.write("No Discount Awarded!" + "<br>");
			document.write("Total Cost: R" + total);
		}else if((duration >= 6) && (duration <= 12))
		{
			discounted = (total - (total * 0.1));
			document.write("10% Discount Awarded!" + "<br>");
			document.write("Total Cost: R" + discounted);
		}else if(duration > 12)
		{
			discounted = (total - (total * 0.2));
			document.write("20% Discount Awarded!" + "<br>");
			document.write("Total Cost: R" + discounted);
		}
	}else	//no upfront payment
	{
		document.write("NO UPFRONT PAYMENT PAID (therefore no discount awarded)" + "<br>");
		document.write("Total Cost: R" + total);
	}
}

//function to handle the "Place Order" button click
function submitForm()
{
	//variables for elements that need to be validated/used
	var nameBox = document.getElementById("name");
	var surnameBox = document.getElementById("surname");
	var sportBox = document.getElementById("sport");
	var movieBox = document.getElementById("movie");
	var seriesBox = document.getElementById("series");
	var durationBox = document.getElementById("duration");
	var upfrontBox = document.getElementById("upfront");
	
	//validating the name and surname field
	if((nameBox.value.length < 1) || (surnameBox.value.length < 1))
	{
		document.getElementById("error").innerHTML = "Missing/incorrect fields - please fill them in properly!";
	}else if((sportBox.checked == false) && (movieBox.checked == false) && (seriesBox.checked == false))
	{
		document.getElementById("error").innerHTML = "Missing/incorrect fields - please fill them in properly!";
	}else if(isNaN(duration.value) || (duration.value < 1) || (duration.value > 24))
	{
		document.getElementById("error").innerHTML = "Missing/incorrect fields - please fill them in properly!";
	}else
	{
		//load summary of entered data
		document.write("Summary: " + "<br>" + "<br>");
		document.write("Name: " + nameBox.value + "<br>");
		document.write("Surname: " + surnameBox.value + "<br>" + "<br>");
		document.write("Packages Selected: " + "<br>");
		if(isChecked(sportBox))	//check if sport checkbox is checked
		{
			document.write(" - Sport Channels" + "<br>");
		}
		if(isChecked(movieBox))	//check if movie checkbox is checked
		{
			document.write(" - Movie Channels" + "<br>");
		}
		if(isChecked(seriesBox))	//check if series checkbox is checked
		{
			document.write(" - Series Channels" + "<br>");
		}
		document.write("<br>" + "Contract Duration: " + durationBox.value + " months" + "<br>" + "<br>");
		cost(durationBox.value, isChecked(upfrontBox));	//calculate and display the total cost
	}
}