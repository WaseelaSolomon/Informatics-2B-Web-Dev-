﻿window.onload = WriteTime();

function WriteTime()
{
    var date = new Date();
 
    var currentdate = "Date: " + date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear() + " Time: " + date.getHours() + ":" + date.getMinutes();
    document.getElementById("timeDiv").innerHTML = currentdate;
}