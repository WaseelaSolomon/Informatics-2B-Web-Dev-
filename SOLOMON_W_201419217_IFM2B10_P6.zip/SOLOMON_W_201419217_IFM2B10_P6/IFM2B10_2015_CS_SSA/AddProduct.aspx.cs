﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class AddProduct : System.Web.UI.Page
    {
        static String connStr = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["UserID"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();

            String query = "INSERT INTO [Product] VALUES ('" + Name.Text + "', '"+ Type.Text +"', '"+ NumItems.Text +"', '"+ ShortDesc.Text +"', '"+ FullDesc.Text +"', 'noimage.jpg')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.ExecuteNonQuery();

            Response.Redirect("Products.aspx");
     
            con.Close();
        }
    }
}