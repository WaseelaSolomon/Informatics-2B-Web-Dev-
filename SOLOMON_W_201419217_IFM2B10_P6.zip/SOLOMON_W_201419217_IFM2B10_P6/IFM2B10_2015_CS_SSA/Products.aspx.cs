﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class Products : System.Web.UI.Page
    {
        static String connStr = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();

            String query = "SELECT * FROM [Product]";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.Text;

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    product.Text += "<h2><a href='ProductInfo.aspx?id=" + dr["ProductID"] + "'>" + dr["Name"] +"</a></h2>";
                    product.Text += "Type: " + dr["Type"] + "<br/>";
                    product.Text += "Number of Available Items: " + dr["NumItems"] + "<br/>";
                    product.Text += "Short Description: " + dr["ShortDescription"] + "<br/><br/>";
                    product.Text += "<img src='App_Media/" + dr["ImageLocation"] + "'/><br/><br/>";
                }
            }

            con.Close();
        }
    }
}