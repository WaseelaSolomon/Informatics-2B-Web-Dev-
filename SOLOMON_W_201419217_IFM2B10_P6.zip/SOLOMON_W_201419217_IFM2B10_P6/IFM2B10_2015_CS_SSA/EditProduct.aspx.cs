﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class EditProduct : System.Web.UI.Page
    {
        static String connStr = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnRetrieve_Click(object sender, EventArgs e)
        {
            con.Open();

            String query = "SELECT * FROM [Product] WHERE Name ='" + Name.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.Text;

            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();

                Type.Text = (String)dr["Type"];
                NumItems.Text = Convert.ToString(dr["NumItems"]);
                ShortDesc.Text = (String)dr["ShortDescription"];
                FullDesc.Text = (String)dr["FullDescription"];
            }

            con.Close();
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();

            String query = "UPDATE [Product] SET Name='" + Name.Text + "', Type='" + Type.Text + "', NumItems='" + NumItems.Text + "', ShortDescription='" + ShortDesc.Text + "', FullDescription='" + FullDesc.Text + "' WHERE Name ='" + Name.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.ExecuteNonQuery();

            Response.Redirect("Products.aspx");

            con.Close();
        }

    }
}