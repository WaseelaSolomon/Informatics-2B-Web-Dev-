﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IFM2B10_2015_CS_SSA
{
    public partial class Login : System.Web.UI.Page
    {
        static String connStr = ConfigurationManager.ConnectionStrings["RugbyWorldConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            con.Open();

            String query = "SELECT * FROM [User] WHERE UserName ='" + UserName.Text + "' AND Password ='" + Password.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = System.Data.CommandType.Text;

            SqlDataReader dr = cmd.ExecuteReader();

            if(dr.HasRows)
            {
                while(dr.Read())
                {
                    Session["UserID"] = "user";
                    Response.Redirect("Products.aspx");
                }
            }

            con.Close();
        }
    }
}